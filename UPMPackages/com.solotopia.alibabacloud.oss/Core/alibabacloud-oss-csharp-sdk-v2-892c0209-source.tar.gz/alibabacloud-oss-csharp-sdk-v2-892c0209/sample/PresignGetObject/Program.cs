﻿using System.Net.Http;
using System.Web;
using CommandLine;
using OSS = AlibabaCloud.OSS.V2;

namespace Sample.PresignGetObject
{
    public class Program
    {

        public class Options
        {
            [Option("region", Required = true, HelpText = "The region in which the bucket is located.")]
            public string? Region { get; set; }

            [Option("endpoint", Required = false, HelpText = "The domain names that other services can use to access OSS.")]
            public string? Endpoint { get; set; }

            [Option("bucket", Required = true, HelpText = "The `name` of the bucket.")]
            public string? Bucket { get; set; }

            [Option("key", Required = true, HelpText = "The `name` of the object.")]
            public string? Key { get; set; }
        }

        public static async Task Main(string[] args)
        {

            var parserResult = Parser.Default.ParseArguments<Options>(args);
            if (parserResult.Errors.Any())
            {
                Environment.Exit(1);
            }
            var option = parserResult.Value;

            // Specify the region and other parameters.
            var region = option.Region;
            var bucket = option.Bucket;
            var endpoint = option.Endpoint;
            var key = option.Key;

            // Using the SDK's default configuration
            // loading credentials values from the environment variables
            var cfg = OSS.Configuration.LoadDefault();
            cfg.CredentialsProvider = new OSS.Credentials.EnvironmentVariableCredentialsProvider();
            cfg.Region = region;

            if (endpoint != null)
            {
                cfg.Endpoint = endpoint;
            }

            using var client = new OSS.Client(cfg);

            var result = client.Presign(new OSS.Models.GetObjectRequest()
            {
                Bucket = bucket,
                Key = key,
            });

            using var hc = new HttpClient();
            var httpResult = await hc.GetAsync(result.Url);
            var stream = await httpResult.Content.ReadAsStreamAsync();
            using var reader = new StreamReader(stream);
            var got = await reader.ReadToEndAsync();

            Console.WriteLine("GetObject done");
            Console.WriteLine($"StatusCode: {httpResult.StatusCode}");
        }
    }
}
